#!/data/data/com.termux/files/usr/bin/bash
echo "Stub action" 
