#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ СТАТУС ═══"
python3 -c "import json; [print(m['name']) for m in json.load(open('barmenu/menu.json'))['modules_watch']]" | while read m; do
    bash barmenu/lib/status.sh "$m" | head -n 1
done
