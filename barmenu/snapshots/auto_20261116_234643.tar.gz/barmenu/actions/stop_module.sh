#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ ЗУПИНКА МОДУЛЯ ═══"
pm2 list
read -p "Який модуль зупинити? (Enter = скасувати): " M
if [ -n "$M" ]; then
    pm2 stop "$M" && ok "Зупинено: $M"
    warn "Відновити: pm2 restart $M"
fi
