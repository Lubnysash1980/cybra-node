#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
read -p "Модуль: " M
read -p "Скільки рядків? (30): " N
N=${N:-30}
pm2 logs "$M" --lines "$N" --nostream
