#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ WATCHDOG: доводимо все до GREEN ═══"
python3 -c "import json; [print(m['name']) for m in json.load(open('barmenu/menu.json'))['modules_watch']]" | while read m; do
    s=$(bash barmenu/lib/status.sh "$m" | tail -n 1)
    if [ "$s" = "RED" ]; then
        warn "$m: перезапуск..."
        pm2 restart "$m" 2>/dev/null
    elif [ "$s" = "YELLOW" ]; then
        info "$m: перезапуск (жовтий)..."
        pm2 restart "$m" 2>/dev/null
    else
        ok "$m: OK"
    fi
done
