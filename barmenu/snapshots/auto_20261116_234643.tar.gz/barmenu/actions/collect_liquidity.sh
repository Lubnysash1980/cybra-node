#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ ЗБІР ЛІКВІДНОСТІ / КОМІСІЙ ═══"
info "Запуск скрипта перевірки позицій..."
node -e '
require("dotenv").config();
const { ethers } = require("ethers");
(async()=>{
  const p = new ethers.JsonRpcProvider(process.env.BSC_RPC_URL);
  const nfpm = new ethers.Contract("0x46A15B0b27311cedF172AB29E4f4766fbE7F4364", ["function balanceOf(address) view returns (uint256)"], p);
  const bal = await nfpm.balanceOf(process.env.WALLET_ADDRESS || "0x9f6b6054d74052c98142a4c3797a078eddd48c58");
  console.log(`📊 NFT-позицій у гаманці: ${bal.toString()}`);
})();'
warn "Для Collect Fees зайди на pancake.finance/info/v3 → My Positions"
