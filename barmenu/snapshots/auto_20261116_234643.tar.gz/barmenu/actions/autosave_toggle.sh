#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
PIDFILE="barmenu/state/autosave.pid"
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then
    kill "$(cat "$PIDFILE")" && rm -f "$PIDFILE"
    warn "Autosave ЗУПИНЕНО"
else
    setsid nohup barmenu/lib/autosave.sh >/dev/null 2>&1 &
    sleep 1
    if [ -f "$PIDFILE" ]; then ok "Autosave ЗАПУЩЕНО (кожні 5 хв, зберігаються 24 год)"
    else err "Не вдалося запустити"; fi
fi
