#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ FIX ЧЕРЕЗ НЕЙРО ═══"
read -p "Модуль (cybra-pool/cybra-brain/parliament): " M
M=${M:-cybra-pool}
s=$(bash barmenu/lib/status.sh "$M" | tail -n 1)
info "$M: $s"
if [ "$s" != "GREEN" ]; then
    info "Відправляємо задачу в Парламент..."
    cybra-it task "[AI-FIX REQUEST] Модуль $M в стані $s — потрібне виправлення"
    ok "Задача створена. Нейро підхопить через cybra-brain."
else
    ok "$M вже зелений."
fi
