#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ NEURO TASK ═══"
read -p "Опис задачі: " TEXT
if [ -n "$TEXT" ]; then
    cybra-it task "$TEXT"
    ok "Задача створена"
fi
