#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ SNAPSHOT ═══"
echo "1) Створити зараз"
echo "2) Список існуючих"
echo "3) Відновити з файлу"
read -p "Обери: " C
mkdir -p barmenu/snapshots
TS=$(date +%Y%m%d_%H%M%S)
case "$C" in
1)
    tar -czf "barmenu/snapshots/manual_$TS.tar.gz" \
        --exclude='node_modules' --exclude='.git' \
        modules bin parliament barmenu .env
    ok "Створено: barmenu/snapshots/manual_$TS.tar.gz"
    ;;
2)
    ls -lh barmenu/snapshots/ | tail -20
    ;;
3)
    ls barmenu/snapshots/
    read -p "Файл: " F
    [ -f "barmenu/snapshots/$F" ] && tar -xzf "barmenu/snapshots/$F" && ok "Відновлено"
    ;;
esac
