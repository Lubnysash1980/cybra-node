#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ BACKEND: RPC ═══"
CURRENT=$(grep "^BSC_RPC_URL=" .env | cut -d= -f2-)
info "Поточний: $CURRENT"
echo ""
echo "  1) publicnode  https://bsc-rpc.publicnode.com"
echo "  2) llamarpc    https://binance.llamarpc.com"
echo "  3) ankr        https://rpc.ankr.com/bsc"
echo "  4) dataseed    https://bsc-dataseed.binance.org"
read -p "Обери (1-4) або Enter: " C
case "$C" in
    1) NEW="https://bsc-rpc.publicnode.com" ;;
    2) NEW="https://binance.llamarpc.com" ;;
    3) NEW="https://rpc.ankr.com/bsc" ;;
    4) NEW="https://bsc-dataseed.binance.org" ;;
    *) exit 0 ;;
esac
info "Тестую $NEW..."
node -e "const {ethers}=require('ethers'); new ethers.JsonRpcProvider('$NEW').getBlockNumber().then(b=>{console.log('✅ block',b);process.exit(0)}).catch(e=>{console.error('❌',e.message);process.exit(1)})" && {
    sed -i "s|^BSC_RPC_URL=.*|BSC_RPC_URL=$NEW|" .env
    ok "Змінено. Перезапускаю cybra-pool..."
    pm2 restart cybra-pool
} || err "Нода не відповідає, залишаємо стару"
