#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ ПОТОЧНІ ПАРАМЕТРИ .env ═══"
grep -E "^(TOKEN_ADDR|QUOTE_ADDR|FEE_TIER|AMOUNT_HUMAN|PRICE_INCREASE|BSC_RPC_URL)=" .env
read -p "Змінити параметр (напр. AMOUNT_HUMAN) або Enter: " K
if [ -n "$K" ]; then
    read -p "Нове значення: " V
    sed -i "s|^$K=.*|$K=$V|" .env
    ok "$K = $V"
fi
