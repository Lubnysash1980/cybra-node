#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ СТВОРЕННЯ НОВОГО ПУЛУ V3 ═══"
read -p "Адреса токена (за замовч. CYBRA): " T
T=${T:-0x74dA52028E42A37bc89E05c2fD5c52daBE4CB48f}
read -p "Адреса пари (USDT/WBNB): " Q
Q=${Q:-0x55d398326f99059fF775485246999027B3197955}
read -p "Fee tier (500/2500/10000): " F
F=${F:-2500}
read -p "Кількість токена (напр. 100): " A
A=${A:-100}
read -p "Цільова ціна в USDT (напр. 400000000): " P
P=${P:-100}

cp .env .env.bak
sed -i "s|^TOKEN_ADDR=.*|TOKEN_ADDR=$T|" .env
sed -i "s|^QUOTE_ADDR=.*|QUOTE_ADDR=$Q|" .env
sed -i "s|^FEE_TIER=.*|FEE_TIER=$F|" .env
sed -i "s|^AMOUNT_HUMAN=.*|AMOUNT_HUMAN=$A|" .env

# Розрахунок ціни → tick → діапазон
TARGET_USDT=$P node -e '
const price = 1 / Number(process.env.TARGET_USDT);
const tick = Math.round(Math.log(price)/Math.log(1.0001));
const spacing = 50;
const low = Math.floor((tick-1000)/spacing)*spacing;
const up  = Math.ceil ((tick+1000)/spacing)*spacing;
console.log(`📊 Ціна: ${process.env.TARGET_USDT} USDT/CYBRA`);
console.log(`📊 targetTick = ${tick}`);
console.log(`📊 tickLower = ${low}`);
console.log(`📊 tickUpper = ${up}`);
'
ok "Параметри записано в .env. Далі — mint через BscScan (як робили раніше)."
