#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ NEURO: редагування меню ═══"
echo "1) Додати пункт"
echo "2) Видалити пункт (disable)"
echo "3) Увімкнути пункт"
read -p "Обери: " C
case "$C" in
1)
    read -p "Назва: " L
    read -p "Action (напр. my_custom): " A
    [ -f "barmenu/actions/$A.sh" ] || echo '#!/data/data/com.termux/files/usr/bin/bash
echo "Stub action" ' > "barmenu/actions/$A.sh"
    python3 -c "
import json
d=json.load(open('barmenu/menu.json'))
new_id=str(max([int(x['id']) for x in d['items']])+1)
d['items'].append({'id':new_id,'label':'$L','action':'$A','enabled':True})
json.dump(d,open('barmenu/menu.json','w'),ensure_ascii=False,indent=2)
print('✅ Додано ID:',new_id)"
    ;;
2|3)
    read -p "ID пункту: " ID
    NEW=$( [ "$C" = "2" ] && echo "False" || echo "True" )
    python3 -c "
import json
d=json.load(open('barmenu/menu.json'))
for it in d['items']:
    if it['id']=='$ID': it['enabled']=$NEW
json.dump(d,open('barmenu/menu.json','w'),ensure_ascii=False,indent=2)
print('✅ Оновлено')"
    ;;
esac
