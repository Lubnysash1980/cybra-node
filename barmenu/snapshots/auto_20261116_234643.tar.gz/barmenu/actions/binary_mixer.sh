#!/data/data/com.termux/files/usr/bin/bash
. barmenu/lib/colors.sh
title "═══ BINARY MIXER ═══"
echo "1) list   — всі снапшоти"
echo "2) diff   — порівняти два"
echo "3) merge  — змішати в один"
echo "4) apply  — застосувати"
read -p "Обери: " C
case "$C" in
1) python3 barmenu/binary_mixer.py list ;;
2)
    python3 barmenu/binary_mixer.py list
    read -p "Снапшот A: " A
    read -p "Снапшот B: " B
    python3 barmenu/binary_mixer.py diff "$A" "$B"
    ;;
3)
    python3 barmenu/binary_mixer.py list
    read -p "Файли через пробіл: " FILES
    read -p "Назва результату (mixed_X.tar.gz): " OUT
    python3 barmenu/binary_mixer.py merge "$OUT" $FILES
    ;;
4)
    python3 barmenu/binary_mixer.py list
    read -p "Патч: " P
    python3 barmenu/binary_mixer.py apply "$P"
    ;;
esac
