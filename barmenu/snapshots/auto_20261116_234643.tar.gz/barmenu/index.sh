#!/data/data/com.termux/files/usr/bin/bash
cd ~/CYBRA
. barmenu/lib/colors.sh

while true; do
    clear
    echo -e "${CYAN}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${CYAN}║   🏛️  CYBRA BAR-MENU  v1.0                   ║${NC}"
    echo -e "${CYAN}╚══════════════════════════════════════════════╝${NC}"
    echo ""
    echo "──── СТАТУС МОДУЛІВ ────"
    python3 -c "import json; [print(m['name']) for m in json.load(open('barmenu/menu.json'))['modules_watch']]" | while read m; do
        bash barmenu/lib/status.sh "$m" | head -n 1
    done
    echo ""
    echo "──── МЕНЮ ────"
    python3 -c "
import json
d=json.load(open('barmenu/menu.json'))
for it in d['items']:
    if it.get('enabled',True): print(f\"  {it['id']:>2}) {it['label']}\")
"
    echo "   0) Вихід"
    echo ""
    read -p "Обери: " choice
    if [ "$choice" = "0" ] || [ -z "$choice" ]; then exit 0; fi
    action=$(python3 -c "
import json
d=json.load(open('barmenu/menu.json'))
for it in d['items']:
    if it['id']=='$choice' and it.get('enabled',True): print(it['action']); break
")
    if [ -n "$action" ] && [ -f "barmenu/actions/$action.sh" ]; then
        echo ""
        bash "barmenu/actions/$action.sh"
        echo ""
        read -p "Enter для продовження..."
    else
        err "Немає дії для пункту $choice"
        sleep 1
    fi
done
