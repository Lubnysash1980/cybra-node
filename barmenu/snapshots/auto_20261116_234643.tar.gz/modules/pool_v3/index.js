async run(ctx) {
    const { provider, signClient, session, account, env } = ctx;
    console.log("✅ [MOCK AI] Код успішно виправлено Нейро-Департаментом!");
    // Тут міг бути ваш реальний код
    return { success: true };
}
